<?php 
defined( 'ABSPATH' ) || exit;
return array (
  'homepage' => 'https://www.futuramaautoeletrico.com.br',
  'cache_options' => 
  array (
    'breeze-active' => '1',
    'breeze-cross-origin' => '0',
    'breeze-disable-admin' => 
    array (
      'administrator' => 0,
      'editor' => 0,
      'author' => 0,
      'contributor' => 0,
      'subscriber' => 0,
    ),
    'breeze-gzip-compression' => '0',
    'breeze-browser-cache' => '1',
    'breeze-lazy-load' => '0',
    'breeze-lazy-load-native' => '0',
    'breeze-lazy-load-iframes' => '0',
    'breeze-desktop-cache' => '1',
    'breeze-mobile-cache' => '1',
    'breeze-display-clean' => '1',
    'breeze-ttl' => 1440,
    'breeze-minify-html' => '0',
    'breeze-minify-css' => '0',
    'breeze-font-display-swap' => '0',
    'breeze-group-css' => '0',
    'breeze-exclude-css' => 
    array (
    ),
    'breeze-include-inline-css' => '0',
    'breeze-minify-js' => '0',
    'breeze-group-js' => '0',
    'breeze-include-inline-js' => '0',
    'breeze-exclude-js' => 
    array (
    ),
    'breeze-move-to-footer-js' => 
    array (
    ),
    'breeze-defer-js' => 
    array (
    ),
    'breeze-enable-js-delay' => '0',
    'breeze-delay-js-scripts' => 
    array (
    ),
    'no-breeze-no-delay-js' => 
    array (
    ),
    'breeze-delay-all-js' => '0',
    'cdn-active' => '0',
    'cdn-url' => '//www.futuramaautoeletrico.com.br',
    'cdn-content' => 
    array (
    ),
    'cdn-exclude-content' => 
    array (
    ),
    'cdn-relative-path' => '0',
    'auto-purge-varnish' => '1',
    'breeze-varnish-server-ip' => '127.0.0.1',
  ),
  'disable_per_adminuser' => 
  array (
    'administrator' => 0,
    'editor' => 0,
    'author' => 0,
    'contributor' => 0,
    'subscriber' => 0,
  ),
  'exclude_url' => 
  array (
  ),
  'wp-user-roles' => 
  array (
    0 => 'administrator',
    1 => 'editor',
    2 => 'author',
    3 => 'contributor',
    4 => 'subscriber',
  ),
  'enabled-lazy-load' => '0',
  'use-lazy-load-native' => '0',
  'breeze-preload-links' => 0,
  'breeze-lazy-load-iframes' => '0',
  'woocommerce_geolocation_ajax' => 0,
  'permalink_structure' => '/%postname%/',
); 
