<?php if (!defined('ABSPATH')) die('Direct access forbidden.');

$options = array(
    'autrics_post_cat'=>array(
        'type'  => 'icon',
        'label' =>esc_html__('Category icon', 'autrics'),
        'desc'  =>esc_html__('Category icon', 'autrics'),
    ),
);