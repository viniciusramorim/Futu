<div class="not-found text-center">
    <h1><?php esc_html_e('Nothing found!', 'autrics'); ?></h1>
    <p><?php esc_html_e('It looks like nothing was found here. Maybe try a search?','autrics'); ?></p>
    <div class="search-forms"> <?php get_search_form(); ?></div>
</div> <!-- end not-found -->